document.body.onkeyup = function(e) {
    if(e.keyCode == 68) {
        document.body.classList.toggle("dark");
    }
}